import tkinter as tk
import time
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
from SystemArgs import Args
from online_utils import get_last_n_lines, get_raw_data
from people_live_function import Is_People_Live


def main(filename, args):
    lines = get_last_n_lines(filename, args.txt_line_num)
    data = get_raw_data(lines, args.label_name)
    result = []
    for rfid in data:
        if len(rfid) > 0:
            state = Is_People_Live(rfid)
        else:
            state = ['RFID 消失!', np.zeros(1000)]
        result.append(state)
    return result


if __name__ == "__main__":
    args = Args()
    filename = args.filename

    root = tk.Tk()
    root.title(args.system_name)
    root.geometry("400x750")

    # 创建系统名称标签
    system_name_label = tk.Label(root, text=args.system_name, font=("Helvetica", 18, "bold"), bg="lightgray")
    system_name_label.grid(row=0, column=0, columnspan=4, pady=10, sticky='ew')

    # 设置标签和变量
    label1_id_var = tk.StringVar()
    name1_var = tk.StringVar()
    person1_id_var = tk.StringVar()
    reader1_loc_var = tk.StringVar()
    conn1_var = tk.StringVar()
    time1_var = tk.StringVar()
    state1_var = tk.StringVar()
    alert1_var = tk.StringVar()

    # 使用frame来分组相关的widgets，使得布局更清晰
    frame = tk.Frame(root, bg="lightblue")
    frame.grid(row=1, column=0, columnspan=4, sticky='nsew', pady=10)

    tk.Label(frame, text=f"{args.feature_name[0]}:", bg="lightblue").grid(row=0, column=0, sticky='e')
    tk.Label(frame, textvariable=label1_id_var, bg="lightblue").grid(row=0, column=1, sticky='w')
    label1_id_var.set(args.samples[0][0])

    tk.Label(frame, text=f"{args.feature_name[1]}:", bg="lightblue").grid(row=1, column=0, sticky='e')
    tk.Label(frame, textvariable=name1_var, bg="lightblue").grid(row=1, column=1, sticky='w')
    name1_var.set(args.samples[0][1])

    tk.Label(frame, text=f"{args.feature_name[2]}:", bg="lightblue").grid(row=1, column=2, sticky='e')
    tk.Label(frame, textvariable=person1_id_var, bg="lightblue").grid(row=1, column=3, sticky='w')
    person1_id_var.set(args.samples[0][2])

    tk.Label(frame, text=f"{args.feature_name[3]}:", bg="lightblue").grid(row=2, column=0, sticky='e')
    tk.Label(frame, textvariable=reader1_loc_var, bg="lightblue").grid(row=2, column=1, sticky='w')
    reader1_loc_var.set(args.samples[0][3])

    tk.Label(frame, text=f"{args.feature_name[4]}:", bg="lightblue").grid(row=2, column=2, sticky='e')
    tk.Label(frame, textvariable=conn1_var, bg="lightblue").grid(row=2, column=3, sticky='w')
    conn1_var.set(args.samples[0][4])

    tk.Label(frame, text="时间:", bg="lightblue").grid(row=3, column=0, sticky='e')
    tk.Label(frame, textvariable=time1_var, bg="lightblue").grid(row=3, column=1, sticky='w')

    tk.Label(frame, text="状态:", bg="lightblue").grid(row=3, column=2, sticky='e')
    tk.Label(frame, textvariable=state1_var, bg="lightblue").grid(row=3, column=3, sticky='w')

    # 新增报警标签
    alert1_label = tk.Label(frame, textvariable=alert1_var, font=("Helvetica", 12))
    alert1_label.grid(row=4, column=0, columnspan=4)

    # 创建图形区域
    fig, ax = plt.subplots(figsize=(4, 2))
    fig.tight_layout()
    canvas = FigureCanvasTkAgg(fig, master=root)
    canvas.get_tk_widget().grid(row=5, column=0, columnspan=4, sticky='nsew')

    # 设置标签和变量
    label2_id_var = tk.StringVar()
    name2_var = tk.StringVar()
    person2_id_var = tk.StringVar()
    reader2_loc_var = tk.StringVar()
    conn2_var = tk.StringVar()
    time2_var = tk.StringVar()
    state2_var = tk.StringVar()
    alert2_var = tk.StringVar()

    # 使用frame来分组相关的widgets，使得布局更清晰
    frame2 = tk.Frame(root, bg="lightblue")
    frame2.grid(row=6, column=0, columnspan=4, sticky='nsew', pady=10)

    tk.Label(frame2, text=f"{args.feature_name[0]}:", bg="lightblue").grid(row=0, column=0, sticky='e')
    tk.Label(frame2, textvariable=label2_id_var, bg="lightblue").grid(row=0, column=1, sticky='w')
    label2_id_var.set(args.samples[1][0])

    tk.Label(frame2, text=f"{args.feature_name[1]}:", bg="lightblue").grid(row=1, column=0, sticky='e')
    tk.Label(frame2, textvariable=name2_var, bg="lightblue").grid(row=1, column=1, sticky='w')
    name2_var.set(args.samples[1][1])

    tk.Label(frame2, text=f"{args.feature_name[2]}:", bg="lightblue").grid(row=1, column=2, sticky='e')
    tk.Label(frame2, textvariable=person2_id_var, bg="lightblue").grid(row=1, column=3, sticky='w')
    person2_id_var.set(args.samples[1][2])

    tk.Label(frame2, text=f"{args.feature_name[3]}:", bg="lightblue").grid(row=2, column=0, sticky='e')
    tk.Label(frame2, textvariable=reader2_loc_var, bg="lightblue").grid(row=2, column=1, sticky='w')
    reader2_loc_var.set(args.samples[0][3])

    tk.Label(frame2, text=f"{args.feature_name[4]}:", bg="lightblue").grid(row=2, column=2, sticky='e')
    tk.Label(frame2, textvariable=conn2_var, bg="lightblue").grid(row=2, column=3, sticky='w')
    conn2_var.set(args.samples[0][4])

    tk.Label(frame2, text="时间:", bg="lightblue").grid(row=3, column=0, sticky='e')
    tk.Label(frame2, textvariable=time2_var, bg="lightblue").grid(row=3, column=1, sticky='w')

    tk.Label(frame2, text="状态:", bg="lightblue").grid(row=3, column=2, sticky='e')
    tk.Label(frame2, textvariable=state2_var, bg="lightblue").grid(row=3, column=3, sticky='w')

    # 新增报警标签
    alert2_label = tk.Label(frame2, textvariable=alert2_var, font=("Helvetica", 12))
    alert2_label.grid(row=4, column=0, columnspan=4)

    # 创建图形区域
    fig2, ax2 = plt.subplots(figsize=(4, 2))
    fig2.tight_layout()
    canvas2 = FigureCanvasTkAgg(fig2, master=root)
    canvas2.get_tk_widget().grid(row=10, column=0, columnspan=4, sticky='nsew')

    # 创建报警窗口
    alert_window = tk.Toplevel(root)
    alert_window.title("报警")
    alert_window.geometry("500x300")
    alert_text_var = tk.StringVar()
    alert_label = tk.Label(alert_window, textvariable=alert_text_var, fg="red", font=("Helvetica", 14, "bold"))
    alert_label.pack(padx=20, pady=20)


    # 更新界面的函数
    def update_gui():
        t = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        result = main(filename, args)

        time1_var.set(t)
        state1_var.set(result[0][0])
        if result[0][0] != "活体":
            alert1_var.set("ID:0 报警")
            alert1_label.config(fg="red")
        else:
            alert1_var.set("ID:0 正常")
            alert1_label.config(fg="black")
        ax.clear()
        ax.plot(result[0][1], color='b')
        ax.set_ylim((0, 2 * np.pi))
        ax.set_ylabel('Phase')
        fig.tight_layout()
        canvas.draw()

        time2_var.set(t)
        state2_var.set(result[1][0])
        if result[1][0] != "活体":
            alert2_var.set("ID:1 报警")
            alert2_label.config(fg="red")
        else:
            alert2_var.set("ID:1 正常")
            alert2_label.config(fg="black")

        if result[0][0] != "活体" and result[1][0] != "活体":
            alert_text_var.set(f"{t}\n"
                               f"标签 ID:{args.samples[0][0]}\n"
                               f"姓名: {args.samples[0][1]}    用户ID: {args.samples[0][2]}\n"
                               f"读写器位置: {args.samples[0][3]}    备注:{args.samples[0][4]}\n"
                               f"状态报警: 未检测到活体信号!!\n\n"
                               f"标签 ID:{args.samples[1][0]}\n"
                               f"姓名: {args.samples[1][1]}    用户ID: {args.samples[1][2]}\n"
                               f"读写器位置: {args.samples[1][3]}    备注:{args.samples[1][4]}\n"
                               f"状态报警: 未检测到活体信号!!")
        elif result[0][0] != "活体":
            alert_text_var.set(f"{t}\n"
                               f"标签 ID:{args.samples[0][0]}\n"
                               f"姓名: {args.samples[0][1]}    用户ID: {args.samples[0][2]}\n"
                               f"读写器位置: {args.samples[0][3]}    备注:{args.samples[0][4]}\n"
                               f"状态报警: 未检测到活体信号!!")
        elif result[1][0] != "活体":
            alert_text_var.set(f"{t}\n"
                               f"标签 ID:{args.samples[1][0]}\n"
                               f"姓名: {args.samples[1][1]}    用户ID: {args.samples[1][2]}\n"
                               f"读写器位置: {args.samples[1][3]}    备注:{args.samples[1][4]}\n"
                               f"状态报警: 未检测到活体信号!!")
        else:
            alert_text_var.set(f"{t}\n"
                               f"正常")

        ax2.clear()
        ax2.plot(result[1][1], color='b')
        ax2.set_ylim((0, 2 * np.pi))
        ax2.set_ylabel('Phase')
        fig2.tight_layout()
        canvas2.draw()

        # 设置定时器，5秒后再次调用update_gui
        root.after(5000, update_gui)


    update_gui()

    root.mainloop()
