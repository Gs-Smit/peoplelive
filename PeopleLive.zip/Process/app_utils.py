import numpy as np
from online_utils import get_last_n_lines, get_raw_data
from people_live_function import Is_People_Live
import time
from pandas import read_csv
from SystemArgs import Args


def initial():
    df = read_csv('people_data.csv')
    data = df.values
    prisoners = data[data[:, -1] == '犯人']
    others = data[data[:, -1] != '犯人']
    label_name_prisoners = {prisoners[i, 2]: i for i in range(len(prisoners))}
    label_name_others = {others[i, 2]: i for i in range(len(others))}

    df_ants = read_csv('ant_data.csv')
    ants = df_ants.values
    ants = {ants[i, 0]: ants[i, 1] for i in range(len(ants))}

    args = Args()
    return prisoners, others, label_name_prisoners, label_name_others, ants, args


def is_out(rfid, args):
    count = 0
    for i in range(len(rfid)):
        if rfid[i][-1] == 3 or rfid[i][-2] == 4:
            count += 1
    if count >= args.out_num:
        return True
    else:
        return False


def people_out(filename, prisoners, others, label_name_prisoners, label_name_others, args):
    lines = get_last_n_lines(filename, args.txt_line_num)
    data_prisoners = get_raw_data(lines, label_name_prisoners)
    data_others = get_raw_data(lines, label_name_others)
    result = []
    for i in range(len(others)):
        other = data_others[i]
        if len(other) == 0:
            pass
        else:
            rfid = np.array(other)
            out = is_out(rfid, args)
            if out:
                result.append([others[i][0], others[i][1], others[i][2], others[i][8]])
            else:
                pass
    for i in range(len(prisoners)):
        prisoner = data_prisoners[i]
        if len(prisoner) == 0:
            pass
        else:
            rfid = np.array(prisoner)
            out = is_out(rfid, args)
            if out:
                result.append([prisoners[i][0], prisoners[i][1], prisoners[i][2], prisoners[i][8]])
            else:
                pass
    return result


def main(filename, prisoners, others, label_name_prisoners, label_name_others, ants, args):
    lines = get_last_n_lines(filename, args.txt_line_num)
    data_prisoners = get_raw_data(lines, label_name_prisoners)
    data_others = get_raw_data(lines, label_name_others)
    num_others_not_here = 0
    for i in range(len(others)):
        other = data_others[i]
        if len(other) == 0:
            others[i][3] = '不在场'
            others[i][4] = '未知'
            num_others_not_here += 1
            continue
        rfid = np.array(other)
        current_time = time.time()
        if current_time - rfid[-1, -1] / 1e3 > args.missing_dur:
            others[i][3] = '不在场'
            others[i][4] = '未知'
            num_others_not_here += 1
            continue
        [live_state, smoothed_phase] = Is_People_Live(rfid)
        others[i][4] = live_state
        loc = ants[rfid[-1, -2]]
        others[i][5] = loc

    for i in range(len(prisoners)):
        prisoner = data_prisoners[i]
        if len(prisoner) == 0:
            prisoners[i][3] = '不在场'
            prisoners[i][4] = '未知'
            prisoners[i][5] = '不在场'
            prisoners[i][6] = '是'
            if num_others_not_here > 1:
                prisoners[i][7] = '是'
            else:
                prisoners[i][7] = '否'
            continue
        rfid = np.array(prisoner)
        current_time = time.time()
        if current_time - rfid[-1, -1] / 1e3 > args.missing_dur:
            prisoners[i][3] = '不在场'
            prisoners[i][4] = '未知'
            prisoners[i][5] = '不在场'
            prisoners[i][6] = '是'
            if num_others_not_here > 1:
                prisoners[i][7] = '是'
            else:
                prisoners[i][7] = '否'
            continue
        [live_state, smoothed_phase] = Is_People_Live(rfid)
        prisoners[i][4] = live_state
        loc = ants[rfid[-1, -2]]
        prisoners[i][5] = loc

    return prisoners, others
