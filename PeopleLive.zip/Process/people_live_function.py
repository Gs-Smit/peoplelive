import numpy as np
import scipy.ndimage


def moving_average(data, window_size):
    return np.convolve(data, np.ones(window_size) / window_size, mode='valid')


def Is_People_Live(rfid_data):
    rfid_data = np.array(rfid_data)
    window_size = 30
    top_n = 50
    mu = 10
    sigma = 5  # 高斯核的标准差

    threshold_factor = 0.45

    cal_factor_S_tag1 = []

    raw_rssi = rfid_data[:, 1]
    raw_phase = rfid_data[:, 0]
    raw_phase = np.mod(raw_phase, 2 * np.pi)

    smoothed_rssi = np.diff(raw_rssi)

    smoothed_rssi_tag1 = scipy.ndimage.gaussian_filter(smoothed_rssi, sigma=sigma)

    tem_cal_factor_amp_tag1 = np.std(smoothed_rssi_tag1)

    # 计算平滑数据
    smoothed_phase_tag1 = moving_average(raw_phase, window_size)

    # # 前 top_n 个最大值的平均值
    # top_values = np.partition(smoothed_phase_tag1, -top_n)[-top_n:]
    # mean_of_top_values = np.mean(top_values)
    #
    # # 前 top_n个最小值的平均值
    # top_values = np.partition(smoothed_phase_tag1, top_n - 1)[:top_n]
    # mean_of_top_values = np.mean(top_values)

    # amplitude_range = mean_of_top_values - mean_of_top_values
    amplitude_range = 0
    std_dev = np.std(smoothed_phase_tag1)

    tem_cal_factor_phase_tag1 = amplitude_range + std_dev * mu

    tem_cal_factor_tag1 = 1.0 * tem_cal_factor_amp_tag1 + 1.0 * tem_cal_factor_phase_tag1

    cal_factor_S_tag1.append(tem_cal_factor_tag1)

    # print(tem_cal_factor)

    if tem_cal_factor_tag1 > threshold_factor:
        status_tag1 = "正常"
    else:
        status_tag1 = "异常"

    return [status_tag1, smoothed_phase_tag1]
