import numpy as np
from online_utils import get_last_n_lines, get_raw_data
from people_live_function import Is_People_Live
import time
from pandas import read_csv
from SystemArgs import Args
from app_utils import initial

prisoners, others, label_name_prisoners, label_name_others, ants, args = initial()
lines = get_last_n_lines(args.filename, args.txt_line_num)
data_prisoners = get_raw_data(lines, label_name_prisoners)
a = data_prisoners[0]
a = np.array(a)
import matplotlib.pyplot as plt
plt.figure()
plt.plot(a[:, 1])
plt.show()