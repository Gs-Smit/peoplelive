from flask import Flask, render_template, jsonify
import numpy as np
from pandas import read_csv
from app_utils import main, initial, people_out
from SystemArgs import Args
import time
from datetime import datetime

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/update_data', methods=['GET'])
def update_data():
    prisoners, others, label_name_prisoners, label_name_others, ants, args = initial()
    prisoners, others = main(args.filename, prisoners, others, label_name_prisoners, label_name_others, ants, args)
    # 模拟更新数据
    region_personnel = [
        {"id": prisoners[i][0], "name": prisoners[i][1], "rfid_id": prisoners[i][2], "status": prisoners[i][3],
         "vital_signs": prisoners[i][4],
         "location": prisoners[i][5], "out_of_area": prisoners[i][6], "police_accompanied": prisoners[i][7]} for i in
        range(len(prisoners))
    ]
    extra_personnel = [
        {"id": others[i][0], "name": others[i][1], "rfid_id": others[i][2], "status": others[i][5],
         "vital_signs": others[i][4], "category": others[i][8]}
        for i in range(len(others))
    ]

    return jsonify(region_personnel=region_personnel, extra_personnel=extra_personnel)


@app.route('/update_exit_data', methods=['GET'])
def update_exit_data():
    prisoners, others, label_name_prisoners, label_name_others, ants, args = initial()
    peoples = people_out(args.filename, prisoners, others, label_name_prisoners, label_name_others, args)
    # 获取当前时间作为 exit_time
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # 模拟出门人员数据
    exit_personnel = [
        {"id": peoples[i][0], "name": peoples[i][1], "rfid_id": peoples[i][2], "type": peoples[i][3],
         "exit_time": current_time}
        for i in range(len(peoples))
    ]
    return jsonify(exit_personnel=exit_personnel)


if __name__ == '__main__':
    app.run(debug=True)
