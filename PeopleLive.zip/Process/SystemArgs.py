class Args:
    def __init__(self):
        self.update_time = 5
        self.txt_line_num = 6000 * 4
        self.out_num = 10
        self.missing_dur = 300
        self.filename = 'E:\\RFID\\PeopleLive\\FlagBasedMeasurement\\data\\ptimes_distance\\RFID.txt'
