from collections import deque


def get_last_n_lines(filename, n):
    with open(filename, 'r') as file:
        lines = deque(file, maxlen=n)
    return list(lines)


def get_raw_data(lines, label_name):
    data = [[] for _ in range(len(label_name))]
    for line in lines:
        line = line.strip()
        parts = line.split()
        if len(parts) < 4:
            continue
        epc = parts[:-4]
        epc = " ".join(epc)
        if epc in label_name.keys():
            index = label_name[epc]
            new_line = [float(parts[-4]), float(parts[-3]), int(parts[-2]), int(parts[-1])]
            data[index].append(new_line)
    return data

