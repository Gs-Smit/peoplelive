import java.io.*;
import java.net.Socket;
import java.util.List;

public class TCPClient {
    private String serverIp;
    private int serverPort;
    private Socket clientSocket;
    private DataOutputStream outToServer;

    public TCPClient(String serverIp, int serverPort) {
        this.serverIp = serverIp;
        this.serverPort = serverPort;
    }

    public void connect() throws IOException {
        clientSocket = new Socket(serverIp, serverPort);
        outToServer = new DataOutputStream(clientSocket.getOutputStream());
    }

    public void sendData(List<String> dataList) throws IOException {
        // 将整个List<String>数组连接成一个字符串，使用逗号分隔元素
        String dataAsString = String.join("", dataList);

        // 发送字符串数据到服务器
        outToServer.writeUTF(dataAsString);
        outToServer.flush();
    }

    public void disconnect() throws IOException {
        if (clientSocket != null) {
            clientSocket.close();
        }
        if (outToServer != null) {
            outToServer.close();
        }
    }
}