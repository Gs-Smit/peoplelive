import com.impinj.octane.ImpinjReader;
import com.impinj.octane.OctaneSdkException;
import com.impinj.octane.Settings;
import java.io.*;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// TCP客户端类

// RFID数据采集类
public class ReadTags_tcp {
    public static String TEXTNAME = "Monza5-2"; // Filename
    public static String SENSORID = "01"; // Sensor ID
    public static ImpinjReader reader;
    static String dateMsg = "";
    static ArrayList<String> arr = new ArrayList<>();
    static TCPClient tcpClient = new TCPClient("127.0.0.1", 6789); // TCP客户端实例

    static {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("YYMMdd");
        dateMsg += sdf.format(date);
        File file = new File(".\\data" + dateMsg + "\\ftimes_tcp\\");
        if (!file.exists() && !file.isDirectory()) {
            file.mkdirs();
        }
        file = new File(".\\data" + dateMsg + "\\ptimes_tcp\\");
        if (!file.exists() && !file.isDirectory()) {
            file.mkdirs();
        }
    }
    public static void measureFisrtSeenTime() throws Exception {
        Writer ftimes_writer = new FileWriter(".\\data"+dateMsg+"\\ftimes_tcp\\"+TEXTNAME+".txt",true);
        String msg="";
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("YYYY/MM/dd HH:mm:ss");
        msg+=sdf.format(date);
        ftimes_writer.write(msg+"\n");
        ftimes_writer.flush();
        ftimes_writer.close();
    }

    public static void measurePersistenceTime() throws Exception {
        // 记录RFID数据
        try (Writer ptimes_writer = new FileWriter(".\\data" + dateMsg + "\\ptimes_tcp\\100.txt", true)) {
            long begin = System.currentTimeMillis();
            while (System.currentTimeMillis() - begin < 600000000) {
                reader.start();
                Thread.sleep(10000);
                reader.stop();
                Thread.sleep(1000);
                System.out.println("////");
                System.out.println(arr);
                System.out.println("////");
                tcpClient.sendData(arr);
                for (String s : arr) {
                    System.out.println(s);
                    ptimes_writer.write(s);
                }
                // 发送数据到TCP服务器

                //tcpClient.sendData(arr);
                ptimes_writer.flush();
                arr.clear();
//                break;
            }
        }
    }

    public static void main(String[] args) {
        try {
            reader = new ImpinjReader();
            String hostname = "speedwayr-11-D5-D4";
            reader.connect(hostname + ".local");
            reader.applySettings(Settings.load("ReadTags/settings.json"));
            reader.setTagReportListener(new TagReportListenerImplementation_tcp());
            tcpClient.connect();
            measureFisrtSeenTime();
            measurePersistenceTime();

            reader.disconnect();
            tcpClient.disconnect();
        } catch (OctaneSdkException | IOException ex) {
            System.out.println(ex.getMessage());
        } catch (Exception ex) {
            ex.printStackTrace(System.out);
        }
    }
}
