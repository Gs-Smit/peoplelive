import com.impinj.octane.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by Xingyu on 2021/5/13.
 * Generate settings.
 */

public class ReaderSettings {
    public static void main(String[] args) {
        // Input the hostname or IP address of the reader in command line.
        System.out.println("Input the  hostname of the reader");
        Scanner scanner = new Scanner(System.in);
        String hostname = "speedwayr-12-7B-4B";
        ImpinjReader reader = new ImpinjReader();
        try {
            reader.connect(hostname+".local");
        } catch (OctaneSdkException e) {
            e.printStackTrace();
        }
        Settings settings = reader.queryDefaultSettings();
        settings.setReaderMode(ReaderMode.MaxThroughput);
        // Thermotag uses the persistence time of session 1 as the metric to do temperature sensing.
        // The corresponding settings are given below.
        settings.setSearchMode(SearchMode.SingleTarget); // Query A
        settings.setSession(0); // Session 1
        settings.setTagPopulationEstimate(1);
        ArrayList<AntennaConfig> arrayList = settings.getAntennas().getAntennaConfigs();
        for (AntennaConfig ac : arrayList) {
            ac.setEnabled(false);
            ac.setIsMaxTxPower(false);
            ac.setTxPowerinDbm(31.5);//31.5->28.5->25.5
            ac.setIsMaxRxSensitivity(true);
        }
        AntennaConfig ac0 = arrayList.get(0);
        ac0.setEnabled(true);

        AntennaConfig ac1 = arrayList.get(1);
        ac1.setEnabled(true);

        AntennaConfig ac2 = arrayList.get(2);
        ac2.setEnabled(true);

        AntennaConfig ac3 = arrayList.get(3);
        ac3.setEnabled(true);


        ReportConfig r = settings.getReport();
        r.setIncludeAntennaPortNumber(true);
        r.setIncludeFirstSeenTime(true);
        r.setIncludeLastSeenTime(true);
        r.setIncludeFastId(true);
        r.setIncludePeakRssi(true);
        r.setIncludePcBits(true);
        r.setIncludeChannel(true);
        r.setIncludeDopplerFrequency(true);
        r.setIncludePhaseAngle(true);
        r.setMode(ReportMode.Individual);
        settings.setReport(r);

//        TagFilter t1 = settings.getFilters().getTagFilter1();
//        t1.setBitCount(8);
//        t1.setBitPointer(32);
//        t1.setMemoryBank(MemoryBank.Epc);
//        t1.setFilterOp(TagFilterOp.Match);
//        t1.setTagMask("E280");

//        TagFilter t2 = settings.getFilters().getTagFilter2();
//        t2.setBitCount(8);
//        t2.setBitPointer(32);
//        t2.setMemoryBank(MemoryBank.Epc);
//        t2.setFilterOp(TagFilterOp.Match);
//        t2.setTagMask("B0");

//        settings.getFilters().setMode(TagFilterMode.OnlyFilter1);
        try {
            settings.save("ReadTags/settings.json");
        } catch (IOException e) {
            e.printStackTrace();
        }
        reader.disconnect();
    }
}
