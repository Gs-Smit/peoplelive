import com.impinj.octane.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ReadTags {
    public static String TEXTNAME = "Monza5-2"; // Filename
    public static ImpinjReader reader;
    static ArrayList<String> arr = new ArrayList<>();
    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);


    public static void measureFirstSeenTime() throws Exception {
        Writer ftimes_writer = new FileWriter(".\\data" + "\\ftimes_distance\\" + TEXTNAME + ".txt", false);
        String msg = "";
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("YYYY/MM/dd HH:mm:ss");
        msg += sdf.format(date);
        ftimes_writer.write(msg + "\n");
        ftimes_writer.flush();
        ftimes_writer.close();
    }

    public static void measurePersistenceTime() throws Exception {
        Writer ptimes_writer = new FileWriter(".\\data" + "\\ptimes_distance\\RFID.txt", false);
        scheduler.scheduleAtFixedRate(() -> {
            try {
                reader.start();
                Thread.sleep(20); // Short duration to prevent continuous reading
                reader.stop();
                for (String s : arr) {
                    ptimes_writer.write(s + "\n"); // Ensure data is written line by line
                }
                ptimes_writer.flush();
                arr.clear();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, 0, 10, TimeUnit.MILLISECONDS); // Schedule to run every 500 milliseconds

        Thread.sleep(12000000); // Continue the task
//        scheduler.shutdown();
        ptimes_writer.close();
    }

    public static void main(String[] args) {
        try {
            reader = new ImpinjReader();
            String hostname = "speedwayr-12-7B-4B";
            reader.connect(hostname + ".local");
            reader.applySettings(Settings.load("ReadTags/settings.json"));
            reader.setTagReportListener(new TagReportListenerImplementation());
            measureFirstSeenTime();
            measurePersistenceTime();
            reader.disconnect();
        } catch (OctaneSdkException | IOException e) {
            System.out.println(e.getMessage());
            e.printStackTrace(System.out);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace(System.out);
        }
    }
}
